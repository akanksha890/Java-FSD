package rangeqry;

public class rangeq {

		// TODO Auto-generated method stub
		     static int k = 16;
		     static int N = 10000; 
		     static long table[][] = new long[N][k + 1]; 
		    static void buildSparseTable(int arr[], int n) 
		    { 
		        for (int i = 0; i < n; i++) 
		            table[i][0] = arr[i]; 
		        for (int j = 1; j <= k; j++) 
		            for (int i = 0; i <= n - (1 << j); i++) 
		                table[i][j] = table[i][j - 1] + table[i + (1 << (j - 1))][j - 1]; 
		    } 
		    static long range(int L, int R) 
		    {
		        long sol = 0; 
		        for (int j = k; j >= 0; j--)  
		        { 
		            if (L + (1 << j) - 1 <= R)  
		            { 
		            	sol = sol + table[L][j];
		                L += 1 << j; 
		            } 
		        } 
		        return sol; 
		    }
		    public static void main(String args[]) 
		    { 
		        int arr[] = { 2,3,4,5,6,7}; 
		        int len = arr.length; 
		        buildSparseTable(arr, len); 
		        System.out.println("the sum of 1st to 2nd ele is: "+range(1, 2)); 
		      
		    } 
		
	}


