package doublylinkedlist;

public class traverse {
	      String name;
	      traverse next;
	      traverse prev;
	   
	   public static void main(String[] args)
	   {
	   
		   traverse topForward = new traverse();
	      topForward.name = "1";
	      traverse temp = new traverse();
	      temp.name = "2";
	      traverse topBackward = new traverse();
	      topBackward.name = "3";
	      topForward.next = temp;
	      temp.next = topBackward;
	      topBackward.next = null;
	      topBackward.prev = temp;
	      temp.prev = topForward;
	      topForward.prev = null;

	      // Dump forward singly-linked list.

	      System.out.print("Forward list: ");
	      temp = topForward;
	      while (temp != null)
	      {
	         System.out.print(temp.name);
	         temp = temp.next;
	      }
	      System.out.println();

	      // Dump backward singly-linked list.

	      System.out.print("Backward list: ");
	      temp = topBackward;
	      while (temp != null)
	      {
	         System.out.print(temp.name);
	         temp = temp.prev;
	      }
	      System.out.println();

	   }
	}