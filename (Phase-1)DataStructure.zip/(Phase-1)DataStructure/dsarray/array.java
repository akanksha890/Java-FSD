package dsarray;

class RArray{
	public void rotate(int[] no,int k) {
		if(k>no.length)
			k=k%no.length;
		int[] result=new int[no.length];
		for(int i=0;i<k;i++) {
			result[i]=no[no.length-k+i];
		}
		int j=0;
		for(int i =k;i<no.length;i++) {
			result[i]=no[i];
			j++;
		}
		System.arraycopy(result, 0, no, 0, no.length);
	}
}

public class array {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		RArray ar=new RArray();
		int arr[]= {1,2,3,4,5};
		ar.rotate(arr, 3);
		for(int i=0;i<arr.length;i++) {
			System.out.print(arr[i]+" ");
		}
	}

}
