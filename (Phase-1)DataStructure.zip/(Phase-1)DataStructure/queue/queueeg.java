package queue;

import java.util.LinkedList;
import java.util.Queue;

public class queueeg {

	public static void main(String[] args) {
		Queue<String> ele = new LinkedList<>();
		ele.add("1");
		ele.add("2");
   		ele.add("3");
   		ele.add("4");
   		ele.add("5");
		System.out.println("Queue : " + ele);
		ele.remove();
		System.out.println("After removing 1st element: " + ele);
	}

}
