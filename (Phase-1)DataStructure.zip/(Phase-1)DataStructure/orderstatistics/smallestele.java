package orderstatistics;

import java.util.Arrays;

public class smallestele {
	
	public static int small(Integer[] ar,int k) {
		Arrays.sort(ar);
		return ar[k-1];
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Integer ar[]=new Integer[] {2,8,6,5,0,3,2};
		int k=4;
		System.out.print("4th smallest element is "+small(ar,k));
	}

}
