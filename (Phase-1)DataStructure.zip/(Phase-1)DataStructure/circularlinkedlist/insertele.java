package circularlinkedlist;

public class insertele {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		insertele Obj = new insertele();  
        Obj.addFirst(1);  
        Obj.print();  
        Obj.addFirst(2);  
        Obj.print();    
        } 
    public class Node{  
        int element;  
        Node next; 
        
        public Node(int element) {  
            this.element = element;  
        }  
    } 

    public Node head = null;  
    public Node tail = null;
    
    public void print() {  
        Node current = head;    
        if(head == null) {  
            System.out.println("Empty List");  
        }  
        else {  
            System.out.println("element inserted successfully...");  
            do{     
                
                System.out.print(" "+ current.element);  
                current = current.next;  
            }while(current != head);  
                        System.out.println();  
                    }  
                }
                
    public void addFirst(int data){  
        Node newNode = new Node(data);  
        if(head == null) {  
            head = newNode;  
            tail = newNode;  
            newNode.next = head;  
        }  
        else {  
            Node temp = head;  
            newNode.next = temp;  
            head = newNode;  
            tail.next = head;  
        }  
    }    

	}

