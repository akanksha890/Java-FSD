package exponentialsearch;

import java.util.Arrays;

public class exponential {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] arr= {1,2,3,4,5};
		int len=arr.length;
		int value=4;
		int result=exponential(arr,len,value);
		if(result<0) {
			System.out.println("Not found..");
		}else {
			System.out.println("Element found at: "+result);
		}
	}

	public static int exponential(int[] arr, int len, int value) {
		if(arr[0]==value) {
			return 0;
		}
		int i=1;
		while(i<len && arr[i]<=value) {
			i=i*2;
		}
		return Arrays.binarySearch(arr, i/2,Math.min(i, len),value);
	}
}
