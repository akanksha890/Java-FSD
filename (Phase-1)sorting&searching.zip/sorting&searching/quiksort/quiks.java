package quiksort;

public class quiks {

	int part(int arr[] ,int low,int high) {
		int p=arr[high];
		int i =(low-1);
		for(int j=low;j<high;j++) {
			if(arr[j]<=p) {
				i++;
				int t =arr[i];
				arr[i]=arr[j];
				arr[j]=t;
			}
		}
		int t=arr[i+1];
		arr[i+1]=arr[high];
		arr[high]=t;
		
		return i+1;
	}
	
	void sort(int arr[],int low,int high)
	{
		if(low<high)
		{
			int pi=part(arr,low,high);
			sort(arr,low,pi-1);
			sort(arr,pi+1,low);		
			}
	}
	static void printa(int arr[]) {
		int n =arr.length;
		for(int i=0;i<n;++i)
			System.out.print(arr[i]+" ");
	}

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[]= {3,2,1};
		int n=arr.length;
		System.out.println("array: ");
		printa(arr);
		quiks qs=new quiks();
		qs.sort(arr, 0, n-1);
		System.out.println("\nsorrted array: ");
		printa(arr);
	}

}
