package selectionsort;

public class selection {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] arr= {8,6,4,2,5,0};
		int len=arr.length;
		selsort(arr);
		System.out.println("sorted order is: ");
		for(int i:arr) {
			System.out.print(i);
		}
	}
	public static void selsort(int[] arr) {
		for(int i=0;i<arr.length-1;i++) {
			int index=i;
				for(int j=i+1;j<arr.length;j++) {
					if(arr[j]<arr[index]) {
						index=j;
					}
				}
				int mini=arr[index];
				arr[index]=arr[i];
				arr[i]=mini;
		}

	}
}
