package linearsearch;

import java.util.Scanner;

public class linears {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

				int[] arr= {1,2,3,4,5};
				
				Scanner sc=new Scanner(System.in);
				System.out.println("Enter the  searched element: ");
				int sv=sc.nextInt();
				int result=(int) linear(arr,sv);
				if(result==-1) {
					System.out.println("not found..!");
				}
				else {
					System.out.println("found..!!");
					System.out.println("At "+result+" : "+arr[result]);
				}
			}
			
			public static int linear(int arr[],int a) {
				int arrlen=arr.length;
				for(int i=0;i<arrlen-1;i++) {
					if(arr[i]==a) {
						return i;
					}
				}
				return -1;
			}
	}

