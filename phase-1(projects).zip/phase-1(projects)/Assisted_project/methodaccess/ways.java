package methodaccess;

public class ways {

			static void staticmsg() {
				System.out.println("I am Static method message");
			}
			
			void nonstaticmsg() {
				System.out.println("I am Non-static method message");
			}
			static int add(int x,int y) {
				return x+y;
			}
			static double add(double x,double y)
			{
				return x+y;
			}
			
			public static void main(String[] args) {
				
				int i=add(2,4);
				double d=add(2,5);
				
				System.out.println("overloading example value of int "+i);
				System.out.println("overloading example value of float "+d);

				staticmsg();
				//created object for class
				ways st=new ways();
				
				//uncomment to see the error as static method cannot be called using object.
				//st.staticmsg();
				st.nonstaticmsg();//used object for calling non static method
			
				
			}
			
		}


