package javahandson;

public class proclass {

	//public static void main(String[] args) {
		// TODO Auto-generated method stub

	protected void show1() {
			System.out.println("I am protected class");
		}
	}
