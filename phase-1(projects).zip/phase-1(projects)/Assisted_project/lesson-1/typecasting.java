package javahandson;

public class typecasting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// implicit type conversion
		int input1 = 200;
		double i1 = input1;
		System.out.println("implicit conersion = " + i1);

		// explicit type conversion
		double input2=200.00;
		int i2=(int)input2;
		System.out.println("explicit conersion = " + i2);

	}

}
