package javahandson;


class p1 {
	void show() {
		System.out.println("I am default class");

	}
}

class p2 {
	public void show() {
		System.out.println("I am public class");
	}
}

//uncomment the below class to see the private class 
//It throws error as its private which cannot be accessed by other class
/*
 * class p2 { private void show() { System.out.println(" I am private class"); }
 * }
 */
public class accessmodifier extends proclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		{
			p1 obj = new p1();
			obj.show();

			p2 obj1 = new p2();
			obj1.show();

			proclass obj2 = new proclass();
			obj2.show1();
		}

	}

}
