package typesofconst;

	class add{
		int a=2,b=3;
		
		 add() {
			System.out.println("default constructor(a+b) "+ (a+b));
		}
		 add(int x,int y) {
			int a=x;
			int b=y;
			System.out.println("parametrized constructor(a+b) "+ (a+b));
		}
		
	}


public class consttyp {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		add a=new add(3,5);
		add b=new add();		
	}

}
