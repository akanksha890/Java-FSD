package arrayys;

public class egarrays {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] item= {1,2,3,4,5};//single dimension arrays
		System.out.println("single dimensional arrays");
		System.out.println("first element: "+item[0]);
		System.out.println("second element: "+item[1]);
		System.out.println("third element: "+item[2]);
		System.out.println("fourth element: "+item[3]);
		System.out.println("five element: "+item[4]);

		//multi dimensional array
		int[][] multiitem = {
				{5,3,7},{3,6,2}
		};
		System.out.println();
		System.out.println("multidimensional arrays");
		System.out.println("length of row 2: "+multiitem[0].length);
	}
}
