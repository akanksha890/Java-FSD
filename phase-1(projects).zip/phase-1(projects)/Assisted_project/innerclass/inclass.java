package innerclass;

public class inclass {
	String s="welcome";

	 class innerclass {
		 void show() {
			System.out.println(s+" I am inner class");
		}
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		inclass out = new inclass();
		inclass.innerclass in=out.new innerclass();
		in.show();
		
	}
}

