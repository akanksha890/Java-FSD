package collection;
import java.util.*;

 class typesofcol {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//array list
		ArrayList arr=new ArrayList();
		arr.add("apple");
		arr.add("kiwi");
		System.out.println("aaray list "+arr);
	
	
		//linked list
		LinkedList li=new LinkedList();
		li.add("mango");
		li.add("orange");
		System.out.println("linked List "+li);
	
		//vector
		Vector vec=new Vector();
		vec.add(1);
		vec.add(2);
		System.out.println("vector List "+vec);
		
		//hashset
		HashSet hs=new HashSet();
		hs.add(12.3);
		hs.add(4);
		System.out.print("hashset list "+hs);
	}

}
