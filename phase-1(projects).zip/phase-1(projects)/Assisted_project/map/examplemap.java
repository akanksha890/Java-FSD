package map;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.TreeMap;

public class examplemap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		HashMap<String, Integer> map=new HashMap();
		map.put("mango ",1);
		map.put("apple ",2);
		for(String key: map.keySet()) {
			System.out.println("hashmap values "+(key+map.get(key)));
		}
		
		Hashtable<String, Integer> table=new Hashtable();
		table.put("mango ",3);
		table.put("apple ",4);
		for(String key: table.keySet())
			System.out.println("hashtable values "+(key+table.get(key)));
	
	
		TreeMap<String, Integer> tree=new TreeMap();
		tree.put("mango ",5);
		tree.put("apple ",6);
		for(String key: tree.keySet())
			System.out.println("hashtree values "+(key+tree.get(key)));
	
	}

}
