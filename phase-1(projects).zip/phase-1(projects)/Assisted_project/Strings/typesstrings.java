package Strings;

public class typesstrings {

	public static void main(String[] args) {

		String s = "hello java";
		// length of string
		System.out.println("length=" + s.length());
		// indexof string
		System.out.println("index of w= " + s.indexOf('w'));
		// charAt of the string
		System.out.println("character at 3= " + s.charAt(3));
		// substring of the string
		System.out.println("substring: " + s.substring(3));
		// split for the string
		String[] s2 = s.split(" ");
		System.out.println(s2[0]);
		System.out.println(s2[1]);
		String[] s3 = s.split("o");
		System.out.println("no. of dervied word:" + s3.length);
		System.out.println(s3[0]);
		System.out.println(s3[1]);
		//System.out.println(s3[2]);
		// replace of the string
		System.out.println("Replaced: " + s.replace("l", "j"));
		// touppercase for the string
		System.out.println("uppercase " + s.toUpperCase());
		// tolowercase of the string
		System.out.println("loswercase" + s.toLowerCase());

	}

}
