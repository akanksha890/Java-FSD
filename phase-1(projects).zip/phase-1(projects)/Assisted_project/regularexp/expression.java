package regularexp;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class expression {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String pat="java";
		String check="hello java world";
		Pattern p=Pattern.compile(pat);
		Matcher c=p.matcher(check);
		
		while(c.find())
			System.out.println(check.substring(c.start(),c.end()));
	}

}
