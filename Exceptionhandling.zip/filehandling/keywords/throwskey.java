package keywords;

public class throwskey {

	void div() throws ArithmeticException
	{
		int a=20,b=0,div;
		div=a/b;
		System.out.println("result: "+div);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		throwskey tk= new throwskey();
		try
		{
			tk.div();
		}catch(ArithmeticException e)
		{
			System.out.println("error: "+e.getMessage());
		}
		System.out.println("end of block");

	}

}
