package keywords;

public class typofkeywords {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a=10,b=0,div=0;
		try {
			if(b==0)
				throw( new ArithmeticException("throw block-division error"));
			else {
				div=a/b;
				System.out.println("result: "+div);
			}
		}catch(ArithmeticException e)
		{
			System.out.println("error: "+e.getMessage());
		}
		finally {
			System.out.println("the finall block of result is : "+div);
		}
		System.out.println("end of block");
	}

}
