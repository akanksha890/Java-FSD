package sleepndwait;

import Exception.runnable;

public class sleepwait {

		private static Object obj=new Object();
		public static void main(String args[]) throws InterruptedException
		{
						Thread.sleep(1000);
						System.out.println("thread after sleep");
						synchronized(obj)
						{
							obj.wait(1000);
							System.out.println("object after wait ");
					}
		
	}
}