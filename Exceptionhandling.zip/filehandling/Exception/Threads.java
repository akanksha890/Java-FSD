package Exception;

public class Threads extends Thread {
	public void run() {
		System.out.println("starting thread ");
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Threads th=new Threads();
		th.start();
	}

}
