package Exception;

public class runnable implements Runnable {
	
		public static int n=0;
		public runnable() {}
			public void run() {
				while(runnable.n<=5) {
					try {
						System.out.println("n: "+(++runnable.n));
						Thread.sleep(1000);
					}catch(InterruptedException e) {
						System.out.println("exception in thread "+e.getMessage());
					}
				}
			}
			public static void main(String[] args) {
				runnable rn=new runnable();
				Thread t=new Thread(rn);
				t.start();
		}
		
	}


