package synchronize;

import java.io.*;
import java.util.*;

import Exception.Threads;


class loan{
	public void loan(String msg)
	{
		System.out.println("request for loan ");
		try {
			Thread.sleep(1000);
		}catch(Exception e)
		{
			System.out.println("request inrrupted");
		}
		System.out.println("loan approved");
	}
}
class tloan extends Thread{
	private String msg;
	loan l;
	tloan(String m,loan loanobj){
		msg=m;
		l=loanobj;
		
	}
	public void run()
	{
		synchronized(l) {
			l.loan(msg);
		}
	}
}

 class threadsync {

	public static void main(String[] args) {
	
		loan lo=new loan();
		tloan t1=new tloan("loan 1", lo);
		t1.start();
	}

}
