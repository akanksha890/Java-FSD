package filehandle;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.charset.StandardCharsets;
import java.nio.file.StandardOpenOption;
import java.util.Arrays;
import java.util.List;

public class create {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		createfileclass();	
		createfileoutputstream();
		createfilein();
	}
	private static void createfileclass() throws IOException{
		File f=new File("Desktop//temp.txt");
		
		if(f.createNewFile()) {
			System.out.println("file is created");
		}
		else {
			System.out.println("file already exists");
		}
		FileWriter fw=new FileWriter(f);
		fw.write("hello world ");
		fw.close();
	}
	
	private static void createfileoutputstream() throws IOException{
		String data="hello world ";
		FileOutputStream out=new FileOutputStream("Desktop//temp.txt");
		out.write(data.getBytes());
		out.close();
	}

	private static void createfilein() throws IOException
	{
		String data="hello wrold ";
		Files.write(Paths.get("Desktop//temp.txt"),data.getBytes());
		List<String>lines=Arrays.asList("1 st line","2nd line");
		Files.write(Paths.get("file6.txt"),
		lines,
		StandardCharsets.UTF_8,
		StandardOpenOption.CREATE,
		StandardOpenOption.APPEND);
	}
}
