package handlers;

class handle extends Exception 
{
	String str;
	handle(String str2){
		str=str2;
	}
	public String toString() {
		return("exception occured "+str);
	}
}
class excphandler{
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			System.out.println("try block ");
			throw new handle("error message");
		}catch(handle e) {
			System.out.println("catch block: "+e);
		}
		
	}

}
