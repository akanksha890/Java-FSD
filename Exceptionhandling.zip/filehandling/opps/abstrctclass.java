package opps;

public abstract class abstrctclass{

	void cmnfunc() {
		System.out.println("i am in the abstact class");
	}
	
	abstract void accelerate();
}
