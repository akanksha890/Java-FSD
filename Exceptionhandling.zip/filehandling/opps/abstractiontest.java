package opps;

public class abstractiontest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		carabstraction th=new carabstraction();
		th.accelerate();
	}

}
