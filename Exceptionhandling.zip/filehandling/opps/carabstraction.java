package opps;

public class carabstraction extends abstrctclass {

	void accelerate(){
		System.out.println("i am the car carabstract class");
	}
}
