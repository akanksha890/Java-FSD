package opps;

public class encapstest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		encapsstudent stu=new encapsstudent();
		stu.id=1;
		stu.name="ashish";
		stu.age=25;
		stu.course="MBA";
		stu.show();
	}

}
