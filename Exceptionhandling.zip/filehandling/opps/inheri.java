package opps;

public class inheri {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		childinheri c = new childinheri();
	}

}
