package opps;

public class childinheri extends parentinhri {

		childinheri(){
			System.out.println("child object"+this);
		}
			void f2(){
				System.out.println("inside child class");
			}
	}


