package opps;

public class encapsstudent {

	int id;
	String name;
	int age;
	String course;
	
	void show() {
		System.out.println("student id: "+id+" student name: "+name+" student age: "+age+" student course: "+course);
		
	}
}
