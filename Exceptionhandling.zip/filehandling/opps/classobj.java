package opps;

public class classobj {
		
			String name;
			int regno;
			String course;
			public classobj(String name,int regno,String course)
			{
				this.name=name;
				this.regno=regno;
				this.course=course;
			}
			public String getname() {
				return name;
			}
			public int getregno() {
				return regno;
			}
			public String getcourse() {
				return course;
			}
			@Override
			public String toString() {
				return(this.getname()+this.getregno()+this.getcourse());
			}
			
			public static void main(String[] args) {
				classobj student=new classobj("joey  ",101,"  MBA ");
				System.out.println(student.toString());
		}
	}


