package opps;

public class polymorphism {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		polymorphism obj= new polymorphism();
		obj.add(2,4);
		obj.add(3,4,5);
	}
	void add(int a, int b) {
		int sum=a+b;
		System.out.println("a+b= "+sum);
	}
	void add(int a,int b,int c) {
		int sum=a+b+c;
		System.out.println("a+b+c= "+sum);
	}
	}

