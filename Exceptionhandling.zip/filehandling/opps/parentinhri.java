package opps;

public class parentinhri {

		parentinhri(){
			System.out.println("parent object"+this);
		}
			

			void f1() {
				System.out.println("inside parent class");
			}
	}


