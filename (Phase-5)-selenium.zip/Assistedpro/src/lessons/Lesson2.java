package lessons;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Lesson2 {
	public static void main (String[] args) {
		WebDriver webdriver = null;
		
		System.setProperty("webdriver.chrome.driver","C:\\tools\\chromedriver_win32\\chromedriver.exe");
		webdriver=new ChromeDriver();
		
		webdriver.get("http://localhost:4200");
		System.out.println(webdriver.getTitle());
		System.out.println(webdriver.getCurrentUrl());
		
		addPosts(webdriver,"tforms","joey");
		
		
	}

	private static void addPosts(WebDriver webdriver, String route, String username) {
		// TODO Auto-generated method stub
		webdriver.get("http://localhost:4200"+"/"+route);
		webdriver.findElement(By.id("username")).sendKeys(username);
		webdriver.findElement(By.className("form-control"));
		webdriver.findElement(By.name("username"));
		webdriver.findElement(By.partialLinkText("ulink"));
		webdriver.findElement(By.xpath("//*[@class='relativexapath']"));
		webdriver.findElement(By.xpath("html/body/div[1]/div[1]/div/h4[1]/b"));
		webdriver.findElement(By.cssSelector("input#username"));
		webdriver.findElement(By.cssSelector("input.inputtext"));
		webdriver.findElement(By.cssSelector("input[name=lastName]"));
		webdriver.findElement(By.cssSelector("input.inputtext[tabindex=1]"));
		webdriver.findElement(By.xpath("//*[contains(text(),’sub’]"));
		webdriver.findElement(By.xpath("=//*[@type=’submit’ or @name=’btnReset’]"));
		webdriver.findElement(By.xpath("//label[starts-with(@id,’message’)]"));
		webdriver.findElement(By.xpath("=//td[text()=’UserID’]"));
		webdriver.findElement(By.xpath("=//*[@type=’text’]//following::input"));
		webdriver.findElement(By.xpath("//*[@type=’text’]//preceding::input"));
		webdriver.findElement(By.xpath("//*[@type=’text’]//following-sibling::input"));

	}
}
