package lessons;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Lesson5 {

	public static void main(String[] args) {
		
		WebDriver driver = new ChromeDriver();
		  driver.findElement(By.id("xyz")).sendKeys(Keys.CONTROL + "t");
		  
		  WebDriver driver1 = new ChromeDriver();
		  ((WebElement) driver.findElements(By.id("xyz"))).sendKeys(Keys.CONTROL + "w");

	
	}
}
