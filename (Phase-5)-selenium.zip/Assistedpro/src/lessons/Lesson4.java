package lessons;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Lesson4 {
	public static void main (String[] args) {
		WebDriver driver = new ChromeDriver();
		driver.switchTo().alert().accept();
		
		WebDriver driver1 = new ChromeDriver();
		driver1.switchTo().alert().dismiss();
		
		 WebDriver driver2 = new ChromeDriver();
				 driver.switchTo().alert().getText();
		 
		 WebDriver driver3 = new ChromeDriver();
				 driver.switchTo().alert().sendKeys("text");
		 
		 WebDriver driver4 = new ChromeDriver();
		 driver.switchTo().alert();
		

	}
}
