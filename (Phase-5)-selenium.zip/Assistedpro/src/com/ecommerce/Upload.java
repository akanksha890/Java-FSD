package com.ecommerce;

import java.sql.Driver;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class Upload {

	WebElement browse =Driver.findElement(By.id("uploadfile"));

	browse.sendKeys("D:\\SoftwareTestingMaterial\\UploadFile.txt");
}
