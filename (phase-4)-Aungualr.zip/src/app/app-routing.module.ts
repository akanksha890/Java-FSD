import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PortfolioComponent } from './portfolio/portfolio.component';
import { signinComponent } from './signin/signin.component';
import { SignupComponent } from './signup/signup.component';

const routes: Routes = [
  {path: "portfolio", component:PortfolioComponent},
  {path: "login", component:signinComponent},
  {path: "login/signup", component:SignupComponent},
  {path:"login/signup/signIn", component:signinComponent},
  {path: "signup", component:SignupComponent},
 

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
